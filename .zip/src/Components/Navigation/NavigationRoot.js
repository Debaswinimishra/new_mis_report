import { Link } from "react-router-dom";

function NavigationRoot() {
  return (
    <>
      {/* <nav> */}
      {/* <Link to="/">Home</Link>
        <Link to="fellow">Community Educator(C.E.)</Link>
        <Link to="anganwadi">Anaganwadi</Link>
        <Link to="school">School</Link> */}
      {/* </nav> */}
    </>
  );
}

export default NavigationRoot;
