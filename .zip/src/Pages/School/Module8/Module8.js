import React from "react";

const Module8 = () => {
  return (
    <>
      <div>You are in the School Module8 page!</div>
    </>
  );
};

export default Module8;
