import React from "react";

const Module9 = () => {
  return (
    <>
      <div>You are in the School Module9 page!</div>
    </>
  );
};

export default Module9;
