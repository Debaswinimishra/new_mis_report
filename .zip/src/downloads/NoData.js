import React from "react";



const NoData = () => {

};

export default NoData;
